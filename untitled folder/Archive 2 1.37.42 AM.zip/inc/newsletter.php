<div class="part-4">
    <div class="container">
      <div class="newsletter">
        <div class="newsletter-text">
          <div>
            <img src="img/combeeco-nws.png" alt="">
            <h4>newsletter</h4>
          </div>
          <p>Melden Sie sich für unseren Newsletter an und erhalten Sie jetzt unseren Investoren-Ratgeber als eBook sowie aktuelle
            News über Immobilien.</p>
        </div>

        <div class="newsletter-sign-up">
          <h4>Kostenloss anmelden</h4>
          <form action="">
            <input type="text" placeholder="Ihre E-mail-Adresse">
            <button type="submit">Anmelden</button>
          </form>
        </div>
      </div>
    </div>
    <div id="triangle-down"></div>
  </div>