<img id="menu-opener" src="img/menu.svg" style="">
<img id="closed-menu" src="img/menu_close.svg" style="">
  <div id="menu">
  <nav>


        <ul>
          <div>
            <div class="form-holder levelHolderClass rtl" data-level="2">
               <div class="hide-text">
              <h3 style="">Wie können wir Ihnen helfen?</h3>
              <p>Schreiben Sie uns und wir werden uns umgehend bei Ihnen melden!</p>
              </div>
              <div id="first-form" class="form-dropdown">
                <p>kontaktformular</p>
                <i class="fa fa-plus"></i>
              </div>

              <form id="first-form-child" action="">
                <input id="input-name" type="text" name="Name" value="" placeholder="Name">
                <input type="text" name="E-mail" value="" placeholder="E-mail">
                <textarea name="message" rows="4" cols="40" placeholder="Nachricht"></textarea>
                <button type="submit">senden</button>
              </form>
              <p style="margin-top: 20px;">oder vereinbaren Sie einen Rückruftermin</p>

              <div id="second-form" class="form-dropdown">
                <p style="padding-left: 20px;">
                  <i class="fa fa-phone" style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%);"></i>Jetzt rückruf anforden </p>
                <i class="fa fa-plus"></i>
              </div>

              <form id="second-form-child" action="">
                <input id="input-name-2" type="text" name="Name"  placeholder="Vollname">
                <input type="text" name="" value="" placeholder="Telefonnummer">
                <input type="text" name="" value="" placeholder="Datum">
                <input type="text" name="" value="" placeholder="Uhrzeit (09.00-18.00)">
                <button type="submit">senden</button>
              </form>
              <p style="margin-bottom: 20px; margin-top: 20px">Unser Service-Team ist
                <span style="font-weight: 600;">Montag bis Freitag</span>
                <span style="font-weight: 600;">von 9 bis 18</span> Uhr für Sie da.</p>
              <p>combeeco GmbH</p>
              <p>
                <span style="font-weight: 600;">Gartenstraße 77</span>
              </p>
              <p>4169 Berlin</p>
              <p>+49 (0) 30 222 123 334</p>
              <p>info@combeeco.de</p>
            </div>
          </div>
        </ul>

  </nav>
</div>