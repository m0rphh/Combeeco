<div style="height: 100px">
  <div class="top-menu stick">
    <div class="site-logo">

      <a href="index.php">
        <img id="logo-black" src="img/comeeco_logo_black.svg" alt="">
      </a>
      <a href="index.php">
        <img id="logo-white" src="img/logo-white.svg" alt="">
      </a>

    </div>

    <div class="main-navigation">
      <div class="language-menu">
        <a href="#">en</a>
        <a class="active" href="#">de</a>
      </div>
      <ul>
        <li>
          <a href="project.php">projekte</a>
        </li>
        <li>
          <a href="funktionert.php">So funktioniert´s</a>
        </li>
        <li>
          <a href="about-us.php">Über uns</a>
        </li>
        <li>
          <a href="">Wissen</a>
        </li>
        <li>
          <a class="registration btn-effect-light" href="">Registrieren</a>
        </li>
        <li>
          <a class="login btn-effect-dark" href="">Anmelden</a>
        </li>
      </ul>
    </div>
  </div>
</div>